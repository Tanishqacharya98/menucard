// mealData.js
export const mealOptions = {
    "One Pot Meal": ["Poha", "Idli", "Dosa"],
    "Carbs": ["Rice", "Roti", "Pav"],
    "Protein": ["Chicken", "Egg Curry", "Paneer Bhurji"],
    "Paratha": ["Paneer Paratha", "Plain Paratha", "Mix Paratha"],
    "Greens": ["Palak", "Methi", "Bhindi"]
  };
  export const snacksMealOptions = {
    "Snacks":["Almonds","oats","Sandwitch","samosa"]
  }